import React from "react";
import RouterMain from "./router";

export default function App() {
  return (
    <>
      <RouterMain />
    </>
  );
}
